<?php 
$experimentid= $_GET['exp'];
$participantid= $_GET['MID']; 


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charser="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="PraneetSoni">
	<title>Delayed Discounting Task Intro</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href= "css/style.css" rel ="stylesheet" type="text/css">
	<link href='http://fonts.googleapis.com/css?family=Slabo+27px' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="container">
	
	
	<div class="row" style="padding-top:5px;padding-bottom:5px;">	
		<div class="col-md-12">
			<img src="http://placehold.it/1170x300" class="img-responsive">
		</div>	
	</div>
	<div class="row" style="padding-top:5px;padding-bottom:5px;">
		<div class="col-md-12">
			<h1>Welcome to Delayed Discount Task</h1>
			<br>
			<p> You will be presented with a series of choices in which you must indicate preference in a form to receive a given quantity of money, for example, between "R$1.00 now" or "R$10.00 in a year's time."
			</p>
			<br>
		
			<a class="btn btn-success active" href=<?php echo "init.php?exp=".$experimentid."&MID=".$participantid ?>> role="button" style ="width:100px;">
			Start </a>
		</div>

	</div>
	
</div>

</body>
</html>