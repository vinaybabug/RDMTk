<?php
include 'databasemanager.php';
$fields = 'id,option_a,option_b';
$table = 'delayed_discount_que';

$j=1;

$max=0;
$db = new DataBaseManager();
$db->connect();
if(!empty($_POST)){

	if(!empty($_POST['num'])){
	$where = "id=".$_POST['num'];
	$db->delete($table,$where);
	header('Location:edit_db.php',true,302);
	}

	if(!empty($_POST['last'])){
		$last= $_POST['last'];
		$j= $_POST['#'];
		$j_prev =$j;
		$max= $_POST['max'];
		$db->sql('SELECT '.$fields. ' FROM '.$table. ' WHERE id>'.$last.' LIMIT 10');
		$result=$db->getResult();
	}

	if(!empty($_POST['prev'])){
		$prev= $_POST['prev'];
		$j= $_POST['#']-10;
		$j_prev =$j;
		$max= $_POST['max'];
		$db->sql('SELECT '.$fields. ' FROM '.$table. ' WHERE id<'.$prev.' ORDER BY id DESC LIMIT 10');
		$result=$db->getResult();
		$prev = $result[9]['id'];
		$db->sql('SELECT '.$fields. ' FROM '.$table. ' WHERE id>='.$prev.' LIMIT 10');
		$result=$db->getResult();

	}

}
else{
$prev=0;
$last=0;
$j_prev=0;
$db->sql('SELECT '.$fields. ' FROM '.$table);
$result=$db->getResult();
$max = count($result);

$db->sql('SELECT '.$fields. ' FROM '.$table. ' WHERE id>'.$last.' LIMIT 10');
$result=$db->getResult(); }
$db->disconnect();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="PraneetSoni">
	<title>Edit DelayD tabel</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="container">
	  	<div class="panel panel-default" style="margin-top:30px;">
	  		<table class="table table-responsive table-hover">
				
				<tr class="row active lead text-center">
					<td class="col-md-2">#</td>
					<td class="col-md-3">Choice A</td>
					<td class="col-md-3">Choise B</td>
					<td class="col-md-2"></td>
					<td class="col-md-2"></td>
				</tr>
				
				
				<?php $i=0;
					$str="";
					$count = count($result);
					for($i;$i<$count;$i++){
						$str.= "<tr class='row text-center'>";
						$str.= "<td class='col-md-2'>".$j."</td>";
						$str.= "<td class='col-md-3'>".$result[$i]['option_a']."</td>";
						$str.= "<td class='col-md-3'>".$result[$i]['option_b']."</td>";
						$str.= "<td class='col-md-2'><form action='edit_row.php' method='POST'><input type='hidden' name='num' value=".$result[$i]['id']."><input type='submit' class='btn btn-primary' value='Edit' style='width:100px;'></form></td>";
						$str.= "<td class='col-md-2'><form action='edit_db.php' method='POST'><input type='hidden' name='num' value=".$result[$i]['id']."><input type='submit' class='btn btn-danger' value='Delete' style='width:100px;'></form></td>";
						$str.= "</tr>";
						$j++;
					}
					echo $str;

					?>
				
			</table>
	   	</div>
	   	
		  	<div class="well well-sm">
		  		
			  		<form action="edit_db.php" method="POST" style="display:inline;"><input type="hidden" name="prev" value=<?php echo $result[0]['id']; ?>>
			  			<input type="hidden" name="#" value=<?php echo $j_prev; ?>><input type="hidden" name="max" value=<?php echo $max; ?>>
			  			<input class="btn btn-default" type="Submit" <?php if($j_prev<11){ echo "disabled ='disabled'"; }?> value="<<"></form>
			  		
			  		<form action="edit_db.php" method="POST" style="display:inline;"><input type="hidden" name="last" value=<?php echo $result[$i-1]['id']; ?>>
			  			<input type="hidden" name="#" value=<?php echo $j; ?>><input type="hidden" name="max" value=<?php echo $max; ?>>
			  			<input class="btn btn-default" type="Submit" <?php if($j>$max){ echo "disabled ='disabled'"; }?> value=">>"></form>
		  			<a role="button" class="btn btn-info" style="display:inline;float:right;" href="new_row.php"> Add a new entry</a>
		  	</div>
	    
	</div>
</body>
</html>