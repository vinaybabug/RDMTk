<?php
include 'databasemanager.php';

$arr = array(1=>array("option_a"=>"$0.5 for sure","option_b"=>"$10 with 90% chance"),2=>array("option_a"=>"$1.5 now","option_b"=>"$10 in 180 days"),3=>array("option_a"=>"$2 now","option_b"=>"$10 in 30 days"));
//$arr = array(1=>array("option_a"=>"$1 now","option_b"=>"$10 in 2 days"),2=>array("option_a"=>"$4.5 now","option_b"=>"$10 in 365 days"));
$table= 'delayed_discount_que';
$db= new DataBaseManager();
$db->connect();
foreach($arr as $array){
$status= $db->insert($table,$array);}
unset($array);
$db->disconnect();
?>
<html>
<head>
	<title>Data entry</title>

</head>
<body>
	<h1><?php
		if ($status)
			{echo "Data entry successful..!<br>";}
		else{
			echo "Data Entry unsuccessful.<br>";
		}

		?>
		
	</h1>

</body>
</html>


