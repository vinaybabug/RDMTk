CREATE SCHEMA IF NOT EXISTS testing;
USE testing;

DROP TABLE IF EXISTS delayed_discount_que;

CREATE TABLE IF NOT EXISTS delayed_discount_que(
id int NOT NULL AUTO_INCREMENT,
option_b varchar(100) NOT NULL,
option_a varchar(100) NOT NULL,
PRIMARY KEY (id)
);