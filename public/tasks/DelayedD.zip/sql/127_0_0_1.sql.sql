-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2015 at 08:50 PM
-- Server version: 5.6.24
-- PHP Version: 5.5.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `testing`
--

-- --------------------------------------------------------

--
-- Table structure for table `delayed_discount_que`
--

CREATE TABLE IF NOT EXISTS `delayed_discount_que` (
  `id` int(11) NOT NULL,
  `option_b` varchar(100) NOT NULL,
  `option_a` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delayed_discount_que`
--

INSERT INTO `delayed_discount_que` (`id`, `option_b`, `option_a`) VALUES
(1, '$10 in 365 days', '$1.5 Now'),
(2, '$7.5 in 10 days', '$1 now'),
(5, '$10 with 50% chance', '$3.5 for sure'),
(6, '$10 with 100% chance', '$7.5 for sure'),
(7, '$10 with 90% chance', '$0.5 for sure'),
(9, '$10 in 2 days', '$1 now'),
(10, '$10 in 365 days', '$4.5 now'),
(11, '$10 in 2 days', '$1 now'),
(13, '$10 with 90% chance', '$0.5 for sure'),
(14, '$10 in 180 days', '$1.5 now'),
(15, '$10 in 30 days', '$2 now'),
(16, '$10 with 90% chance', '$0.5 for sure'),
(17, '$10 in 180 days', '$1.5 now'),
(18, '$10 in 30 days', '$2 now'),
(19, '$10 with 90% chance', '$0.5 for sure'),
(20, '$10 in 180 days', '$1.5 now'),
(21, '$10 in 30 days', '$2 now'),
(22, '$10 with 90% chance', '$0.5 for sure'),
(23, '$10 in 180 days', '$1.5 now'),
(24, '$10 in 30 days', '$2 now');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `delayed_discount_que`
--
ALTER TABLE `delayed_discount_que`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `delayed_discount_que`
--
ALTER TABLE `delayed_discount_que`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
