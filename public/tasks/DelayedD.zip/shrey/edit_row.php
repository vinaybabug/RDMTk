<?php  
include 'databasemanager.php';
$table="delayed_discount_que";
if(!empty($_POST['num'])){

	$id= $_POST['num'];
	$db = new DataBaseManager();
	$db->connect();
	$db->sql('SELECT option_a,option_b,correct_option FROM '.$table.' WHERE id='.$id);
	$res = $db->getResult();
	if(!empty($_POST['option_a']) && !empty($_POST['option_b']) ){
		$db->sql('UPDATE '.$table. ' SET option_a="'.$_POST["option_a"].'", option_b="'.$_POST['option_b'].'",correct_option="'.$_POST['correct_option'].'" WHERE id='.$id);
		Header("Location:edit_db.php",true,302);
	}

	$db->disconnect();
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="PraneetSoni">
	<title>Edit DelayD Row</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="container">
		<div class="panel panel-default" style="margin-top:30px;">
			<div class="panel-heading">
				<h2>Edit the question</h2>
			</div>
			<div class="panel-body">
				<h3>What would you prefer:
				</h3>

				<form method="POST" action="edit_row.php">
					<input type="hidden" name="num" value=<?php echo $id; ?>>
 					<h3>Choice A:</h3>
					<textarea cols="100" rows="5" style="width:900px; height:200px;" placeholder ="<?php  echo $res[0]['option_a']; ?>" name= "option_a"></textarea>
					<br><br>
					<h3>Choice B:</h3>
					<textarea cols="100" rows="5" style="width:900px; height:200px;"" placeholder = "<?php  echo $res[0]['option_b']; ?>" name= "option_b"></textarea>
					<br><br><br>
                    <h3>Choose Correct Option :</h3>
                    
   <select name="correct_option" role="button"  class="btn btn-info" >
 
  <option value="0">Option A</option>
  <option value="1">Option B</option>
</select>   
                    <br><br><br>
                    
					
					<input type="submit" class="btn btn-primary" value="Go"></input>
					<a href="edit_db.php" class="btn btn-default">Cancel</a>
				</form>

			</div>
		</div>

	</div>

</body>
</html>
