<?php  
include 'databasemanager.php';
$table="delayed_discount_que";
if(!empty($_POST)){
	
	$db = new DataBaseManager();
	$db->connect();

	if(!empty($_POST['option_a']) && !empty($_POST['option_b']) ){
		$db->sql('INSERT INTO '.$table.'(option_a,option_b) VALUES ("'.$_POST["option_a"].'","'.$_POST["option_b"].'")');
		Header("Location:edit_db.php",true,302);
	}

	$db->disconnect();
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="PraneetSoni">
	<title>Edit DelayD Row</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="container">
		<div class="panel panel-default" style="margin-top:30px;">
			<div class="panel-heading">
				<h2>Create the new Entry</h2>
			</div>
			<div class="panel-body">
				<h3>What would you prefer:
				</h3>

				<form method="POST" action="new_row.php">
					<h3>Choice A:</h3>
					<textarea cols="100" rows="5" style="width:900px; height:200px;" placeholder ="Enter question for choice A" name= "option_a"></textarea>
					<br><br>
					<h3>Choice B:</h3>
					<textarea cols="100" rows="5" style="width:900px; height:200px;"" placeholder = "Enter question for choice B" name= "option_b"></textarea>
					<br><br><br>
                    <h3>Choose Correct Option :</h3>
                    
   <select name="correct_option" role="button"  class="btn btn-info" >
 
  <option value="0">Option A</option>
  <option value="1">Option B</option>
</select>   
                    
					<br><br><br>
					<input type="submit" class="btn btn-primary" value="Go"></input>
					<a href="edit_db.php" class="btn btn-default">Cancel</a>
				</form>
				<h1><?php //echo "'option_a'=>'".$_POST['option_a']."','option_b'=>'".$_POST['option_b']."'"; 

				?></h1>
			</div>
		</div>

	</div>

</body>
</html>
