<?php 
include 'databasemanager.php';
$fields = 'id,option_a,option_b';
$table = 'delayed_discount_que';
$no_trials = 11;
$count = 1;
$prev=0;
if(!empty($_POST)){
$count = $_POST['count'];
$prev= $_POST['prev'];
}
$prog = (($count-1) *100)/ $no_trials;
$db = new DataBaseManager();
$db->connect();
$db->sql('SELECT '.$fields.' FROM '.$table. ' WHERE id>'.$prev. ' LIMIT 1');
$res = $db->getResult();
$db->disconnect();

function url($count,$no_trials){
		if($count< $no_trials){
			return "task.php";		
		}
		else{
			return "end.html";
			}
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charser="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="PraneetSoni">
	<title>Delayed Discounting task</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="css/task_style.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="container-fluid" >
		<div class="row col-md-12 text-center" style="padding-top:150px;">
			
				Que. What would you rather prefer:
				
		
		</div>
		<div class="row">
			<div class="col-md-6 text-center">
				<button type="button" disabled ="disabled" class="btn btn-default">A</button>
				<?php echo $res[0]['option_a']; ?>
			</div>
			
			<div class="col-md-6 text-center">
				<button type="button" disabled ="disabled" class="btn btn-default">B</button><?php echo $res[0]['option_b']; ?>
			</div>
		</div>
		<br>
		<br><br>
		<div class="row text-center" >
			<form action ="<?php echo url($count,$no_trials); ?>" method="POST">
			<input type="hidden" name="count" value=<?php echo ++$count ?>></input>
			<input type="hidden" name="prev" value=<?php echo $res[0]['id']; ?>></input>
			<input type="submit" name="ans_a" class="btn btn-info" style="width:100px;" value="A"></input>
			<input type="submit" name="ans_b" class="btn btn-info" style="width:100px;" value="B"></input>
			</form>
		</div>
		<br><br>
		<br><br><br>
		<div class="progress">
			<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="<?php echo $prog;?>" area-valuemin="0" area-valuemax="100" style="width:<?php echo $prog;?>%"></div>
			</div>
		</div>
	</div>
</body>
</html>