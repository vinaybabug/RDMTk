<?php 
/**
* Copyright (C) 2015  WiSe Lab, Computer Science Department, Western Michigan University
*Project Members Involved: Ajay Gupta, Aakash Gupta, Baba Shiv, Praneet Soni, Shrey Gupta and Vinay B Gavirangaswamy
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>
*/

/* Retrieves the experiment id and user id allotted  */
$experimentid= $_GET['exp'];
$participantid= $_GET['MID']; 

include 'include/class/oe_databasemanager.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charser="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="PraneetSoni">
	<title>Delayed Discounting Task Intro</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href= "css/style.css" rel ="stylesheet" type="text/css">
	<link href='http://fonts.googleapis.com/css?family=Slabo+27px' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="container">
	
	
	<div class="row" style="padding-top:5px;padding-bottom:5px;">	
		<div class="col-md-12">
			<img src="" style="height:410px;" class="img-responsive center-block">
		</div>	
	</div>
	<div class="row" style="padding-top:5px;padding-bottom:5px;">
		<div class="col-md-12">
			<h1>Welcome to "XYZ" Task</h1>
			<br>
			<p> You will be presented with a series of choices in which you must indicate preference in a form to receive a given quantity of money.
			</p>
			
			
			<a class="btn btn-success active" type="button" href="init.php" value ="Submit" style ="width:100px;">
			
		</div>

	</div>
</div>

</body>
</html>