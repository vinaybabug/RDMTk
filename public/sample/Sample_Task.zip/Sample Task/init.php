<?php 

/**
* Copyright (C) 2015  WiSe Lab, Computer Science Department, Western Michigan University
*Project Members Involved: Ajay Gupta, Aakash Gupta, Baba Shiv, Praneet Soni, Shrey Gupta and Vinay B Gavirangaswamy
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>
*/


include 'include/class/oe_databasemanager.php';
include 'users/controller/user_dbo.php';


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charser="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="">
	<title>Delayed Discounting task</title>
	
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="../../js/jquery.min.js"></script>
	<script type="text/javascript" src="../../js/track.js"></script>
</head>
<body onload="nxt()">
	<div class="container-fluid" >
		<div class="row col-md-12 text-center" style="padding-top:70px;">
			                
        </div>
    </div>
				
</h3>				
   <!--  The following script iterates through the questions and changes the contents of HTML DOM element holding the question everytime an option is selected -->           
  <script type="text/javascript">
   // some script
    </script>
   	
   	       
	
</body>
</html>