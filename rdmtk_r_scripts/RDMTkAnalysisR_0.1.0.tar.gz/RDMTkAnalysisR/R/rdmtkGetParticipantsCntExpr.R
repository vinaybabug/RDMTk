rdmtkGetParticipantsCntExpr <-
function(taskType, exprAID, exprBID, ...){

 cat(sprintf("taskType: %s exprAID: %s exprBID: %s\n", taskType,exprAID,exprBID));
 return(100)
}
